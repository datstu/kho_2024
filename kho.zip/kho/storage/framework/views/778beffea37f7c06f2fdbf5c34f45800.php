<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3">
        <div class="container-lg">

        <?php if($errors->any()): ?>
    <div class="col-sm-12">
        <div class="alert  alert-warning alert-dismissible fade show" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span><p><?php echo e($error); ?></p></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>


<?php if(session('success')): ?>
<div id="noti-box">
    <div class="col-sm-12">
        <div class="alert  alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    </div>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="noti-box ">
    <div class="col-sm-12">
        <div class="alert  alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>
    </div>
    </div>
<?php endif; ?>

          <div class="card mb-4">
            <div class="card-header"><strong>Quản lý đơn hàng</strong> </div>
            <div class="card-body p-0">
              <div class="example mt-0">

<?php echo $__env->make('pages.orders.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
<script>
  $(document).ready(function() {
    $("#noti-box").slideDown('fast').delay(5000).hide(0);
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\kho\resources\views/pages/orders/index.blade.php ENDPATH**/ ?>