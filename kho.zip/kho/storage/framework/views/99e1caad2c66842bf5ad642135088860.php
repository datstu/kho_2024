<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3">
        <div class="container-lg">
          <div class="row">
            <div id="notifi-box" class="hidden alert alert-success print-error-msg" >
              <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
            </div>
            <div class="col-12">
              <div class="card mb-4">
                <div class="card-header"><strong>Thêm sản phẩm  mới </span></div>
                <div class="card-body">
                  <div class="example">
                    <div class="body flex-grow-1">
                      <div class="tab-content rounded-bottom">
                      <form>
                        <?php echo e(csrf_field()); ?>

                        <div class="tab-pane p-3 active preview" role="tabpanel" id="preview-1000">
                          <div class="row">
                          <div class="mb-3 col-8">
                            <label class="form-label" for="nameIP">Tên sản phẩm</label>
                            <input class="form-control" name="name" id="nameIP" type="text">
                            <p class="error_msg" id="name"></p>
                          </div>
                          <div class="mb-3 col-4">
                            <label class="form-label" for="priceIP">Giá</label>
                            <input class="form-control" name="price" id="priceIP" type="bumber">
                            <p class="error_msg" id="price"></p>
                          </div>
                          
                          </div>
                          <div class="mb-3 col-2">
                            <label class="form-label" for="qtyIP">Số lượng</label>
                            <input class="form-control" name="qty" id="qtyIP" type="bumber">
                            <p class="error_msg" id="qty"></p>
                          </div>
                          <button id="submit" class="btn btn-primary"  >Tạo</button>
                        </div>
                      </form>
                      </div>
                    </div>
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<script>
$(document).ready(function() {
  $("#submit").click(function(e){
    e.preventDefault();
  
      var _token = $("input[name='_token']").val();
      var name = $("input[name='name']").val();
      var price = $("input[name='price']").val();
      var qty = $("input[name='qty']").val();

      $.ajax({
          url: "<?php echo e(route('save-product')); ?>",
          type:'POST',
          data: {_token:_token, name:name, price:price, qty:qty},
          success: function(data) {
            console.log(data);
              if($.isEmptyObject(data.errors)){
                  $(".error_msg").html('');
                  $("#notifi-box").show();
                  $("#notifi-box").html('Sản phẩm đã được tạo thành công.');
                  $("#notifi-box").slideDown('fast').delay(5000).hide(0);
              }else{
                  let resp = data.errors;
                  for (index in resp) {
                    console.log(index);
                    console.log(resp[index]);
                      $("#" + index).html(resp[index]);
                  }
              }
          }
      });
 
  
  }); 
});
   </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\kho\resources\views/pages/product/add.blade.php ENDPATH**/ ?>