
<?php $__env->startSection('content'); ?>

<style>
    .card-header a.btn-warning {
        color: #fff;
        float: right;
    }
    iFrame {
        width: 100%;
        height: 100vh;
    }
    iFrame .header-main {
        display: none;
    }
    
    .footer {
        display: none;
    }

    .hidden-iframe {
    height: 80px;
    position: fixed;
    background: #fff;
    width: 100%;
    }
</style>
<link href="<?php echo e(asset('public/css/pages/styleShippingOrders.css')); ?>" rel="stylesheet">
<?php 
?>
<link href="<?php echo e(asset('public/css/pages/styleOrders.css')); ?>" rel="stylesheet">



<iFrame id="iFrame" src="https://donhang.ghn.vn/?order_code=<?php echo e($orderCode); ?>" width="680" height="480" allowfullscreen></iFrame>

<script>
    $("#iFrame").contents().find(".header-main").style.display = 'none';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\kho\resources\views/pages/orders/detailshipping.blade.php ENDPATH**/ ?>