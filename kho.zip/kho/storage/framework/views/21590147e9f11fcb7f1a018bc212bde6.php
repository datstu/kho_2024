<?php $__env->startSection('content'); ?>
<div class="body flex-grow-1 px-3">
        <div class="container-lg">

        <?php if($errors->any()): ?>
    <div class="col-sm-12">
        <div class="alert  alert-warning alert-dismissible fade show" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span><p><?php echo e($error); ?></p></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>


<?php if(session('success')): ?>
<div id="noti-box">
    <div class="col-sm-12">
        <div class="alert  alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    </div>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="noti-box ">
    <div class="col-sm-12">
        <div class="alert  alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>
    </div>
    </div>
<?php endif; ?>

<?php
$active       = '';
$routeName    = \Route::getCurrentRoute()->uri;
$asRouteName  = (\Route::getCurrentRoute()->action['as']) ?? null;
?>
          <div class="card mb-4">
            <div class="card-header"><strong>Quản lý sản phẩm</strong> </div>
            <div class="card-body">
              <div class="example mt-0">
                <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item"><a class="nav-link  <?= ($routeName == 'danh-sach-san-pham')?'active':'' ?>"  href="<?php echo e(URL::to('/danh-sach-san-pham')); ?>">
                      <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('public/vendors/@coreui/icons/svg/free.svg#cil-media-play')); ?>"></use>
                      </svg>Danh sách</a></li>
                  <li class="nav-item"><a class="nav-link <?= ($asRouteName == 'nhap-hang-theo-thang' || $routeName == 'nhap-hang')?'active':'' ?>" href="<?php echo e(URL::to('/nhap-hang')); ?>">
                      <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('public/vendors/@coreui/icons/svg/free.svg#cil-code')); ?>"></use>
                      </svg>Nhập hàng</a>
                  </li>
                  <li class="nav-item"><a class="nav-link" href="" target="_blank">
                      <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('public/vendors/@coreui/icons/svg/free.svg#cil-code')); ?>"></use>
                      </svg>Xuất hàng</a>
                  </li>
                  <li class="nav-item"><a class="nav-link" href="" target="_blank">
                      <svg class="icon me-2">
                        <use xlink:href="<?php echo e(asset('public/vendors/@coreui/icons/svg/free.svg#cil-code')); ?>"></use>
                      </svg>Tồn kho</a>
                  </li>
                </ul>
<?php
  if ($routeName == 'nhap-hang' || $asRouteName == 'nhap-hang-theo-thang' || $asRouteName == 'nhap-hang-theo-nam') :
?>

<?php echo $__env->make('pages.product.contentSetProducts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
  //elseif ($routeName == 'danh-sach-san-pham') :
  else :
?>

<?php echo $__env->make('pages.product.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
  endif
?>


              </div>
            </div>
          </div>
        </div>
      </div>
<script>
  $(document).ready(function() {
    $("#noti-box").slideDown('fast').delay(5000).hide(0);
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\company\kho\resources\views/pages/product/index.blade.php ENDPATH**/ ?>