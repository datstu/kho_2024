 <!-- CoreUI and necessary plugins-->
 <script src="<?php echo e(asset('public/vendors/@coreui/coreui/js/coreui.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/vendors/simplebar/js/simplebar.min.js')); ?>"></script>
    <!-- Plugins and scripts required by this view-->
     
<?php /**PATH C:\xampp\htdocs\company\kho\resources\views/includes/foot.blade.php ENDPATH**/ ?>