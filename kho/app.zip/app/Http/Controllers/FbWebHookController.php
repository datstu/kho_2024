<?php

namespace App\Http\Controllers;

use App\Helpers\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class FbWebHookController extends Controller
{
    //
    public function webhook(Request $req) 
    {
        $data = $req->all();
 
        // Log::channel('new')->info('api run webhook');
        // Log::channel('new')->info($data);
        if ($data) {
            $this->callDataPc($data);
        }
    }

    // Hàm gửi tin nhắn sử dụng Facebook Send API
    function sendTextMessage($senderPsid, $message)
    {
        global $PAGE_ACCESS_TOKEN;
        $url = 'https://graph.facebook.com/v13.0/me/messages?access_token=' . $PAGE_ACCESS_TOKEN;
    
        $ch = curl_init($url);
    
        $jsonData = [
            'recipient' => ['id' => $senderPsid],
            'message' => ['text' => $message]
        ];
    
        $jsonDataEncoded = json_encode($jsonData);
    
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
        $result = curl_exec($ch);
        curl_close($ch);
    
        if ($result) {
            echo "Tin nhắn đã được gửi!";
        } else {
            echo "Không thể gửi tin nhắn.";
        }
    }

    public function getUserName($userId, $access_token) {
        // dd($userId);
        $url = "https://graph.facebook.com/$userId?fields=first_name,last_name&access_token=$access_token";
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
    
        $user = json_decode($response, true);
        // if ()
        // dd( $user);
        // Trả về tên đầy đủ hoặc chỉ tên riêng
        return $user['last_name'] . ' ' . $user['first_name'];
    }

    public function saveDataWebhookFB($group, $pageId, $phone, $name, $mId, $messages, $pageSrc)
    {
        // foreach ($data as $item) {
        // $recentPhoneNumbers = $phone;
        // $mId      = $recentPhoneNumbers->m_id;
        // $phone    = isset($recentPhoneNumbers) ? $recentPhoneNumbers->phone_number : '';
        // $name     = isset($item->customers[0]) ? $item->customers[0]->name : '';
        // $messages = isset($recentPhoneNumbers) ? $recentPhoneNumbers->m_content : '';

        $assgin_user = 0;
        $is_duplicate = false;
        $phone = Helper::getCustomPhoneNum($phone);
        $checkSaleCareOld = Helper::checkOrderSaleCarebyPhonePage($phone, $pageId, $mId, $assgin_user, $is_duplicate);

        $chatId = $group->tele_hot_data;
        // dd($chatId);
        $linkPage = $pageSrc->link;
        $namePage = $pageSrc->name;
        if ($checkSaleCareOld) {  
            if ($assgin_user == 0 && $group->sales) {
                // dd($group);
                $assignSale = Helper::getAssignSaleByGroup($group);
                if (!$assignSale) {
                    return;
                }
                $assgin_user = $assignSale->id_user;
            }

            // dd($assgin_user);
            $is_duplicate = ($is_duplicate) ? 1 : 0;
            $sale = new SaleController();
            $data = [
                'page_link' => $linkPage,
                'page_name' => $namePage,
                'sex'       => 0,
                'old_customer' => 0,
                'address'   => '',
                'messages'  => $messages,
                'name'      => $name,
                'phone'     => $phone,
                'page_id'   => $pageId,
                'text'      => 'Page ' . $namePage,
                'chat_id'   => $chatId,
                'm_id'      => $mId,
                'assgin'    => $assgin_user,
                'is_duplicate' => $is_duplicate,
                'group_id'  => $group->id,
            ];

            $request = new \Illuminate\Http\Request();
            $request->replace($data);
            $sale->save($request);
        }
        //   } 
    }


    // Xử lý sự kiện webhook
    public function handle($data)
    {
        Log::channel('new')->info('run webhook googogo ');


          Log::channel('new')->info(($data) ? 'true' : 'false');
          
        if ($data) {
           
          
            $phone = $data['phone'];
            $receivedMessage = $data['receivedMessage'];
            $mid = $data['mid'];
            $name = $data['name'];
            $pageId = $data['pageId'];
            $group = Helper::getGroupByPageId($pageId);
             
            // dd($group);
            if (!$group) {
                return;
            }
            
            $pageSrc = Helper::getPageSrcByPageId($pageId);
            Log::channel('new')->info( $pageSrc ? 'có pageSrc' : 'nono');
            if (!$pageSrc) {
                return;
            }

            $tokenPage = $pageSrc->token;
            if (!$name) {
                $name = "Anh 3";
            }

            $this->saveDataWebhookFB($group, $pageId, $phone, $name, $mid, $receivedMessage, $pageSrc);
        }

            return response('Sự kiện đã nhận', 200);
    }

    public function callDataPc($data)
    {
        $data = array (
            'phone' => '0973409613',
            'receivedMessage' => '0973409613 go',
            'mid' => 'm_3RWA8svAbHssJhEYb3IrlRSX13JMTib20xEA6BqKI-0Zsa9a4XJoKC3Qe_llMV-tF_q9LRDNFhNDPZIUraidmQ',
            'name' => 'Dat Dinh',
            'pageId' => '381180601741468'
        );
    
        $pageId =  $data['pageId'];
        $phone =  $data['phone'];
        $mid =  $data['mid'];
        $receivedMessage = $data['receivedMessage'];
        $group = Helper::getGroupByPageId($pageId);
             
        if (!$group) {
            return;
        }
        
        $pageSrc = Helper::getPageSrcByPageId($pageId);
        if (!$pageSrc) {
            return;
        }

        $token = $pageSrc->token;
        $endpoint = "https://pancake.vn/api/v1/pages/$pageId/conversations/";
        $endpoint .= "search?q=$phone&access_token=$token";
        $responseJson = file_get_contents($endpoint);
        $response = json_decode($responseJson, true);

        if (!$response) {
            return false;
        }

        if (!$response['success'] || !$response['conversations']) {
            return false;
        }

        $data = $response['conversations'][0];
        $name = $data['customers'][0]['name'];
        $this->saveDataWebhookFB($group, $pageId, $phone, $name, $mid, $receivedMessage, $pageSrc);
    }
}