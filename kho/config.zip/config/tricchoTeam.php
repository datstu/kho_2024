<?php
return [
    'list_sale' => [
        'thu' => [
            //Thu
            'name' => 'sale',
            'status' => 1,
        ],
        'hiep' => [
            'name' => 'sale.hiep',
            'status' => 1,
        ],
        'ly' => [
            'name' => 'sale.ly',
            'status' => 1,
        ],
    ],
];