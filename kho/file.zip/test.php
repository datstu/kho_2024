<?php
// namespace App\Http\Controllers;
// use App\Http\Controllers\FbWebHookController;
// require_once('app/Http/Controllers/FbWebHookController.php');
require_once 'app\Http\Controllers\FbWebHookController';

$fbWh =  FbWebHookController::hii();

// echo $fbWh->hii();