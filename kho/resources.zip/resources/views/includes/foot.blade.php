 <!-- CoreUI and necessary plugins-->
 <script src="{{asset('public/vendors/@coreui/coreui/js/coreui.bundle.min.js')}}"></script>
    <script src="{{asset('public/vendors/simplebar/js/simplebar.min.js')}}"></script>
    <!-- Plugins and scripts required by this view-->
     {{-- <script src="{{asset('public/vendors/chart.js/js/chart.min.js')}}"></script> 
    <script src="{{asset('public/vendors/@coreui/chartjs/js/coreui-chartjs.js')}}"></script>
    <script src="{{asset('public/vendors/@coreui/utils/js/coreui-utils.js')}}"></script>
   <script src="{{asset('public/js/main.js')}}"></script> --}}


   {{-- <script type="text/javascript" src="{{ asset('public/js/notify.js'); }}"></script> --}}